"use strict"

let text = document.lastModified;
document.getElementById("date1").innerHTML = text;