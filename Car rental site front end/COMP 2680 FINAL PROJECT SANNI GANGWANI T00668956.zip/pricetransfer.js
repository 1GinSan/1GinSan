testJS();

function testJS()
{

var price = document.getElementById('price').value

document.getElementById('pricebox').innerHTML = price;

}